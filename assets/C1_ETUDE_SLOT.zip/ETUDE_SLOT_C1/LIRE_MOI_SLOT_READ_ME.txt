ETUDE DU SLOT C1 — INTRADOS vers EXTRADOS — mm
401 positions de contact derivees du maillage de la racine : CSV avec normales et tangentes.
STEP/DXF : polyligne d’etude passant par ces points. Les segments sont une approximation discretisee, pas un rail fabrique valide.
DXF COUPES : intersections exactes plan/triangles, un calque COUPE_TIR_001 a 041.
La surface graphique adaptee 25x25 est une representation pour etude ; elle ne valide ni le profil physique du sabot, ni le maintien des 55 degres, ni le passage entre aubes.
Le slot necessite le guidage retenu, son rayon de suiveur, les jeux, la retenue et les collisions avant fabrication.
Origine UT virtuelle et toutes les donnees de detection conservees.

SLOT STUDY — INTRADOS to EXTRADOS — mm
CSV: 401 root-mesh contact positions, normals and tangents. STEP/DXF: study polyline through these points; discrete approximation, not a validated manufactured rail.
Section DXF: exact plane/triangle intersections, one layer per shot. Graphic 25x25 foot is not a validated wedge profile, 55-degree mechanical qualification or blade-clearance validation. Define follower/guidance, offsets, clearances, retention and collisions before manufacture.

CIBLE_VERTICALES : plan vertical contenant le tir nominal, profil cible issu du maillage. CONTACT_OBLIQUES : anciens plans locaux de contact, distincts des coupes cibles. En bout de parcours, le plan traverse la face d extremite : la vue dans l application ajoute un repere voisin decale de 10 mm le long du parcours. Aucun contour de gorge n est invente.
CIBLE_VERTICALES: vertical section through the nominal beam. CONTACT_OBLIQUES: separate local contact sections. At the path end the cut intersects the end face; the app shows an explicitly offset nearby reference profile (10 mm along path). No groove contour is fabricated.
