C1 FINAL FR/EN — 08 novembre 2026 — référence fd9bc24

1. Extraire entièrement ce fichier ZIP.
2. Ouvrir 00_OUVRIR_C1_FINAL_FR_EN.html avec Chrome ou Edge.
3. Utiliser ce seul fichier. Aucun Python ni Streamlit à installer.

Cette version contient la racine centrale opaque, les 41 positions,
la cartographie bleue et ses cinq EDM, les analyses TFM et voxel,
le rapport et les exports d’origine, en français et anglais.
La mécanique de la rupture reste explicitement à compléter.
Les résultats sont ceux du jumeau numérique de référence.

Même version en ligne : https://bytendt-lsb941-c1-fr-en.streamlit.app/
Les anciens onglets peuvent être fermés. Conserver les fichiers sources CAO.

ENGLISH
Extract the ZIP, then open 00_OUVRIR_C1_FINAL_FR_EN.html in Chrome or Edge.
Use this single file; no Python or Streamlit installation is required.
The central root is opaque. Original 41-position results, five EDMs,
TFM, voxel, report and exports are included. Fracture assessment is pending.
