C1 FINAL FR/EN — CORRECTION SENS DE TIR ET PROFONDEUR — 08/11/2026

Extraire ce ZIP puis ouvrir uniquement 00_OUVRIR_C1_FINAL_FR_EN.html.
C1 : tir INTRADOS vers EXTRADOS — 41 positions — 5 EDM.
C2 : tir EXTRADOS vers INTRADOS — 199 positions — 6 EDM (cas distinct).
La racine est opaque. TFM, voxel, rapport et resultats UT conserves.
Courbes : cibles acoustiques d’origine, pas des contours de surface.
Trait plein = partie visible ; pointille = lecture a travers la matiere.
Aucune projection ni modification des coordonnees des cibles.
Mecanique de la rupture : module a completer.

Extract this ZIP and open only 00_OUVRIR_C1_FINAL_FR_EN.html.
C1: INTRADOS to EXTRADOS — 41 positions — 5 EDM.
C2: EXTRADOS to INTRADOS — 199 positions — 6 EDM (separate case).
Opaque root; original UT results, TFM, voxel and report retained.
Curves are original acoustic targets, not surface contours.
Solid = visible; dashed = through-material view. Coordinates unchanged.
Fracture mechanics module pending.
