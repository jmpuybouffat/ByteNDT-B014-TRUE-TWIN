C1 — CONTACT SUR AUBE ET COUPE — FR/EN — 09 novembre 2026

EXTRAIRE le ZIP puis ouvrir uniquement 00_OUVRIR_C1_FINAL_FR_EN.html dans Chrome ou Edge.
Choisir Lecture : glissement continu sur la peau. Les 41 tirs sont affiches au passage des positions, sans arret impose.
Coupe cotee verticale : profil reel de racine, contact, directions de tirs et tache UT courante. En extremite, le profil voisin a 10 mm est un repere hors plan du tir.
3D contact : volume ancre sur la peau ; les voisines sont partiellement coupees pour voir le contact.
C1 : INTRADOS vers EXTRADOS — 41 positions — 5 EDM.
Cartographie, TFM, voxel, rapport et resultats originaux conserves.
Le point O UT est une origine virtuelle ; il ne sert plus de centre au sabot affiche.
Le dossier ETUDE_SLOT_C1 contient les CSV/DXF/STEP pour preparer le guidage.
Ce sont des donnees d etude : profil physique de sabot, jeu, collisions et maintien des 55 degres restent a qualifier. Le champ acoustique physique B006 n est pas encore raccorde : aucune enveloppe illustrative ne le remplace.

EXTRACT the ZIP, then open only 00_OUVRIR_C1_FINAL_FR_EN.html in Chrome or Edge.
Play slides the graphic foot continuously on the root mesh; the 41 acquisitions update on crossing their positions, without a dwell.
The vertical section shows actual root profile, contact, source-law projections and UT samples. At the end, the nearby profile at 10 mm is explicitly outside the shot plane.
3D contact shows the volume anchored to the skin; adjacent blades are partly cut away for visibility.
C1: INTRADOS to EXTRADOS — 41 positions — 5 EDM. Original cartography, TFM, voxel and report retained.
UT O is a virtual origin, separate from the displayed contact.
ETUDE_SLOT_C1 contains CSV/DXF/STEP for guidance study. Physical wedge profile, clearances, collisions and 55-degree mechanical qualification remain to be verified. The B006 physical acoustic field is not yet linked; no illustrative envelope replaces it.
