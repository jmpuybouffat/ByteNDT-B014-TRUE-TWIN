C1 — REFERENCE MECANIQUE 27,6 mm — INTRADOS vers premiere gorge EXTRADOS
Conversion CAO vers mm : x0,1 une seule fois. Courbe mecanique : milieu de premiere gorge du maillage.
401 contacts sur peau et normales interpolees du maillage. Direction centrale 55 degres par rapport a cette normale interpolee. Le sabot graphique adapte 25x25 n est pas un profil de sabot fabrique valide.
41 transformations rigides par pose reconstruisent le rejeu UT dans ce contexte mecanique. Les matrices UT, amplitudes, lois, TFM et voxel sources restent inchanges. Cela ne constitue PAS une nouvelle validation physique des cinq EDM. Les anciens XYZ du rapport sont dans le repere source ; le CSV R/T permet le passage au repere d affichage, pose par pose.
STEP/DXF du contact : polyligne discretisee pour etude du guidage, pas un slot fabrique valide. Definir jeux, suiveur et collisions.

C1 — 27.6mm MECHANICAL REFERENCE — INTRADOS to first EXTRADOS groove
CAD-to-mm scale x0.1 applied once. 401 mesh-skin contacts, interpolated surface normals, central angle55 degrees to those normals. 41 proper rigid pose registrations reconstruct the original UT replay in this mechanical context. Source UT amplitudes, laws, TFM and voxel matrices are unchanged; this is NOT a new physical EDM validation. Original report XYZ remain in the source frame. R/T CSV records the per-pose reconstruction mapping. Discrete STEP/DXF paths are study geometry, not a validated manufactured slot or wedge.

COUPES CIBLE VERTICALES : coupes actuelles au tir nominal. Aucun profil voisin a10mm utilise dans la nouvelle vue.
CURRENT VERTICAL SECTIONS: actual nominal-shot sections. No10mm offset profile is used in the updated view.
